import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Dashboard from './Dashboard';

function App() {
  return (
    <Router>
      <div className="container mt-4">
        <nav className="mb-4">
          <Link to="/" className="btn btn-primary me-2">Главная</Link>
          <Link to="/charts" className="btn btn-success">Графики</Link>
        </nav>

        <Routes>
          <Route path="/" element={<h1>Привет! Это главная страница.</h1>} />
          <Route path="/charts" element={<Dashboard />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;