import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, Container, Row, Col, Spinner, Alert } from 'react-bootstrap';
import { fetchChartData1, fetchChartData2 } from './api';

function Dashboard() {
  const [data1, setData1] = useState([]);
  const [data2, setData2] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Загружаем данные для обеих диаграмм параллельно
        const [chart1Data, chart2Data] = await Promise.all([
          fetchChartData1(),
          fetchChartData2()
        ]);
        
        setData1(chart1Data);
        setData2(chart2Data);
      } catch (err) {
        setError(err.message || 'Ошибка при загрузке данных');
        console.error('Ошибка загрузки:', err);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  // Показываем спиннер во время загрузки
  if (loading) {
    return (
      <Container className="text-center mt-5">
        <Spinner animation="border" variant="primary" />
        <p className="mt-3">Загрузка данных...</p>
      </Container>
    );
  }

  // Показываем ошибку если она есть
  if (error) {
    return (
      <Container className="mt-4">
        <Alert variant="danger">
          <Alert.Heading>Ошибка загрузки данных</Alert.Heading>
          <p>{error}</p>
          <hr />
          <div className="d-flex justify-content-end">
            <button 
              className="btn btn-outline-danger" 
              onClick={() => window.location.reload()}
            >
              Повторить попытку
            </button>
          </div>
        </Alert>
      </Container>
    );
  }

  // Показываем графики
  return (
    <Container>
      <Row className="mb-4">
        <Col md={12}>
          <h2 className="text-center">Сравнительный анализ параметров</h2>
        </Col>
      </Row>
      
      <Row className="mb-4">
        <Col md={12}>
          <Card>
            <Card.Header>Группа 1: Основные параметры</Card.Header>
            <Card.Body>
              <div style={{ width: '100%', height: 400 }}>
                <ResponsiveContainer>
                  <BarChart
                    data={data1}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis type="number" domain={[0, 5]} />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value1" name="Значение 1" fill="#2c5aa0" />
                    <Bar dataKey="value2" name="Значение 2" fill="#7cb342" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row>
        <Col md={12}>
          <Card>
            <Card.Header>Группа 2: Дополнительные показатели</Card.Header>
            <Card.Body>
              <div style={{ width: '100%', height: 400 }}>
                <ResponsiveContainer>
                  <BarChart
                    data={data2}
                    layout="vertical"
                    margin={{ top: 5, right: 30, left: 80, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis type="number" domain={[0, 5]} />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="value1" name="Значение 1" fill="#2c5aa0" />
                    <Bar dataKey="value2" name="Значение 2" fill="#7cb342" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </Container>
  );
}

export default Dashboard;