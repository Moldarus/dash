import axios from 'axios';
import Ajv from 'ajv';

// Инициализация AJV для валидации
const ajv = new Ajv();

// Схема валидации для данных графика
const chartDataSchema = {
  type: "array",
  items: {
    type: "object",
    properties: {
      name: { type: "string" },
      value1: { type: "number" },
      value2: { type: "number" },
    },
    required: ["name", "value1", "value2"],
  },
};

const validateChartData = ajv.compile(chartDataSchema);

// Базовый URL API (пока пустой, позже укажете реальный адрес)
const API_BASE_URL = 'http://localhost:3000/api'; // Замените на ваш API

// Функция для получения данных первой диаграммы
export const fetchChartData1 = async () => {
  // ПОКА ИСПОЛЬЗУЕМ МОК-ДАННЫЕ
  // Когда будет готов API, замените на:
  // const response = await axios.get(`${API_BASE_URL}/chart1`);
  // const data = response.data;
  
  // Имитация задержки сети (можно убрать)
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Мок-данные (структура как будет приходить с API)
  const mockData = {
    data: [
      { name: 'Параметр 1', value1: 2.38, value2: 2.59 },
      { name: 'Параметр 2', value1: 3.07, value2: 3.03 },
      { name: 'Параметр 3', value1: 1.14, value2: 1.48 },
      { name: 'Параметр 4', value1: 2.04, value2: 1.78 },
      { name: 'Параметр 5', value1: 3.46, value2: 3.28 },
      { name: 'Параметр 6', value1: 3.64, value2: 3.71 },
      { name: 'Параметр 7', value1: 3.38, value2: 2.71 },
      { name: 'Параметр 8', value1: 3.26, value2: 3.47 },
    ]
  };

  // Валидация данных
  const valid = validateChartData(mockData.data);
  if (!valid) {
    console.error('Ошибка валидации данных:', validateChartData.errors);
    throw new Error('Данные не прошли валидацию');
  }

  return mockData.data;
  
  // Когда будет реальный API, раскомментируйте это:
  /*
  try {
    const response = await axios.get(`${API_BASE_URL}/chart1`);
    const data = response.data;
    
    // Валидация
    const valid = validateChartData(data);
    if (!valid) {
      throw new Error('Данные не прошли валидацию');
    }
    
    return data;
  } catch (error) {
    console.error('Ошибка при загрузке данных диаграммы 1:', error);
    throw error;
  }
  */
};

// Функция для получения данных второй диаграммы
export const fetchChartData2 = async () => {
  // ПОКА ИСПОЛЬЗУЕМ МОК-ДАННЫЕ
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const mockData = {
    data: [
      { name: 'Показатель A', value1: 4.12, value2: 3.85 },
      { name: 'Показатель B', value1: 2.95, value2: 3.21 },
      { name: 'Показатель C', value1: 1.67, value2: 1.89 },
      { name: 'Показатель D', value1: 3.44, value2: 3.12 },
      { name: 'Показатель E', value1: 2.78, value2: 2.95 },
      { name: 'Показатель F', value1: 4.01, value2: 3.76 },
      { name: 'Показатель G', value1: 3.33, value2: 3.58 },
      { name: 'Показатель H', value1: 2.56, value2: 2.44 },
    ]
  };

  const valid = validateChartData(mockData.data);
  if (!valid) {
    console.error('Ошибка валидации данных:', validateChartData.errors);
    throw new Error('Данные не прошли валидацию');
  }

  return mockData.data;
  
  // Когда будет реальный API:
  /*
  try {
    const response = await axios.get(`${API_BASE_URL}/chart2`);
    const data = response.data;
    
    const valid = validateChartData(data);
    if (!valid) {
      throw new Error('Данные не прошли валидацию');
    }
    
    return data;
  } catch (error) {
    console.error('Ошибка при загрузке данных диаграммы 2:', error);
    throw error;
  }
  */
};